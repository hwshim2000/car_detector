#!/bin/bash

cd /root/car_detector
export CUDA_HOME=/usr/local/cuda
#export NVIDIA_VISIBLE_DEVICES=all
export LD_LIBRARY_PATH=/usr/local/cuda-9.0/lib64:/usr/local/cuda/extras/CUPTI/lib64:/usr/local/nvidia/lib:/usr/local/nvidia/lib64
#export TF_CUDA_VERSION=9.0
#export NVIDIA_DRIVER_CAPABILITIES=compute,utility
export PATH=/usr/local/cuda-9.0/bin:/usr/local/nvidia/bin:/usr/local/cuda/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
#export CUDA_PKG_VERSION=9-0=9.0.176-1
#export CUDA_VERSION=9.0.176
#export CI_BUILD_PYTHON=python3
#export TF_CUDA_COMPUTE_CAPABILITIES=3.0,3.5,5.2,6.0,6.1


PNAME=server.py
PID=`ps -ef | grep $PNAME | grep -v grep | awk '{print $2}'`

start() {
  #/root/car_detector/runServer >> /root/car_detector/start.log
  /root/car_detector/runServer >/dev/null 2>&1 &
  echo [`date`] server started... >> /root/car_detector/run.log
}
stop() {
  kill -9 $PID
  echo [`date`] server stopped... >> /root/car_detector/run.log
}

if [[ "$1" == "start" ]]
then
  if [[ -n "$PID" ]]
  then
    echo "Server[$PNAME] already started..."
  else
    start
    echo "Server[$PNAME] started..."
  fi
elif [[ "$1" == "stop" ]]
then
  if [[ -n "$PID" ]]
  then
    stop
    echo "Server[$PNAME] stopped..."
  else
    echo "Server[$PNAME] not started..."
  fi
elif [[ "$1" == "restart" ]]
then
  if [[ -n "$PID" ]]
  then
    stop
    echo "Server[$PNAME] stopped..."
    start
    echo "Server[$PNAME] restarted..."
  else
    start
    echo "Server[$PNAME] restarted..."
  fi
fi
