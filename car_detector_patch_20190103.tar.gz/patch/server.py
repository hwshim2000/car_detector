#!/usr/bin/python

import os
import sys
sys.path.insert(0, './lib')
import argparse
import web_server

model_list = [
    'car_single_ml_200000',
    'car_single_ml_400000',
    'car_single_ml_600000',

    'car_single_sml_200000',

    'car_multi_ml_200000',
    'car_multi_ml_400000',
    'car_multi_ml_600000',
    'car_multi_ml_800000',
    'car_multi_ml_1000000',

    'car_multi_sml_200000',
    'car_multi_sml_400000',
    'car_multi_sml_600000',
    'car_multi_sml_800000',
    'car_multi_sml_1000000'
]


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('-m', '--model', default=['car_multi_sml_1000000'], choices=model_list, dest="model", help='Trained graph model path.', required=True)
    ap.add_argument('-d', '--debug', default="false", help='Running mode configuration(If GPU is used, debug mode must be set to false).')
    ap.add_argument('-a', '--admin', default="false", help='Admin mode(Please, don\'t use admin mode).')
    ap.add_argument('-s', '--server', default="0.0.0.0", help='Server address(Default value is 0.0.0.0).')
    ap.add_argument('-p', '--port', default=8088, type=int, help='Server port(Default value is 8088).')
    #ap.add_argument('-n', '--detect_nums_per_sec', default=1.0, type=float , help='Detect numbers per sec.(Default value is 100).')
    ap.add_argument('-ds', '--dnp_server', default='192.168.0.198', help='DNP server ip address(Default value is 192.168.0.198)')
    ap.add_argument('-dp', '--dnp_port', default=8090, type=int, help='DNP server port number(Default value is 8090).')

    args = ap.parse_args()
    
    web_server.run(args, model_list)
